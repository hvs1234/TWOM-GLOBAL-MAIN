 <!-- home page service block -->
    <section class="home-services py-5" id="services">
        <div class="container py-md-5 py-4">
            <div class="title-heading-w3 mx-auto text-center mb-sm-5 mb-4 pb-xl-4" style="max-width:600px">
                <h3 class="title-style mb-2">What's Services We Are Offering to Our Customers</h3>
                <p>We believe in empowering our clients with a diverse array of services designed to meet their unique needs.</p>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="box-wrap">
                        <div class="icon">
                            <i class="fas fa-laptop-code blue-clr-bg"></i>
                        </div>
                        <h4 class="number">01</h4>
                        <h4><a href="#url">Brand Development</a></h4>
                        <p>We craft brand identities that inspire, values that innovate, and stories that connect with your audience on a profound level.</p>
                        <a href="#read" class="read">Read more</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-md-0 mt-4">
                    <div class="box-wrap">
                        <div class="icon">
                            <i class="fas fa-chart-bar primary-clr-bg"></i>
                        </div>
                        <h4 class="number">02</h4>
                        <h4><a href="#url">Digital Marketing</a></h4>
                        <p>We excel in using data-driven strategies, SEO expertise, and social media savvy to boost your brand's digital presence
.</p>
                        <a href="#read" class="read">Read more</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-lg-0 mt-4">
                    <div class="box-wrap">
                        <div class="icon">
                            <i class="fas fa-copy green-clr-bg"></i>
                        </div>
                        <h4 class="number">03</h4>
                        <h4><a href="#url">Digital Strategy & Planning</a></h4>
                        <p> Our experts craft bespoke strategies to elevate your online presence, ensuring every digital move aligns with your business goals</p>
                        <a href="#read" class="read">Read more</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-4">
                    <div class="box-wrap">
                        <div class="icon">
                            <i class="fas fa-marker primary-clr-bg"></i>
                        </div>
                        <h4 class="number">04</h4>
                        <h4><a href="#url">Website Design & Development</a></h4>
                        <p>Our team takes a strategic approach, aligning your website with your brand's goals and your audience's needs.</p>
                        <a href="#read" class="read">Read more</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-4">
                    <div class="box-wrap">
                        <div class="icon">
                            <i class="fas fa-user-cog green-clr-bg"></i>
                        </div>
                        <h4 class="number">05</h4>
                        <h4><a href="#url">Video Production</a></h4>
                        <p>Our Videos are meticulously crafted to not only tell your story but also to enhance your brand's image, engage your audience, and drive results.</p>
                        <a href="#read" class="read">Read more</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-4">
                    <div class="box-wrap">
                        <div class="icon">
                            <i class="fas fa-coins blue-clr-bg"></i>
                        </div>
                        <h4 class="number">06</h4>
                        <h4><a href="#url">Documentaries</a></h4>
                        <p>Our documentary services are more than just videos; they are powerful narratives that delve deep into your brand, cause, or message.
</p>
                        <a href="#read" class="read">Read more</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //home page service block -->