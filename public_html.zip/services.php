<!--
Author: W3layouts
Author URL: http://w3layouts.com
-->
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Storytelling, branding and digital experiences.

</title>
    <!-- google-fonts -->
    <link
        href="//fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <!-- //google-fonts -->
    <!-- Font-Awesome-Icons-CSS -->
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
    <!-- Template CSS Style link -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
</head>

<body>
    <!--header-->
    <?php include"header.php";?>
    <!--//header-->

    <!-- inner banner -->
    <section class="inner-banner py-5">
        <div class="w3l-breadcrumb py-lg-5">
            <div class="container pt-4 pb-sm-4">
                <h4 class="inner-text-title font-weight-bold pt-5">Services</h4>
                <ul class="breadcrumbs-custom-path">
                    <li><a href="index.html">Home</a></li>
                    <li class="active"><i class="fas fa-angle-right mx-2"></i>Services</li>
                </ul>
            </div>
        </div>
    </section>
    <!-- //inner banner -->
<?php include"our-services.php"; ?>
    <!-- //service block -->

    <!-- middle -->
    <div class="middle py-5">
        <div class="container py-lg-5 py-4">
            <div class="welcome-left text-center py-lg-4 m-auto" style="max-width:700px;">
                <h5>Any plan to start a project</h5>
                <h3 class="mt-2">Our Experts always ready to work with you.</h3>
                <a href="https://twomglobal.com/contact" class="btn btn-style btn-white mt-sm-5 mt-4">Get started</a>
            </div>
        </div>
    </div>
    <!-- //middle -->

    <!-- faq section -->
    <div class="w3l-faq-block py-5" id="faq">
        <div class="container py-lg-5">
            <div class="row">
                <div class="col-lg-7">
                    <section class="w3l-faq" id="faq">
                        <h3 class="title-style">Learn more from our FAQ</h3>
                        <p class="mt-3">TWOM Global: Your Questions, Our Expertise – Navigating the Path to Creative Excellence.
</p>
                        <div class="faq-page mt-4">
                            <ul>
                                <li>
                                    <input type="checkbox" checked>
                                    <i></i>
                                    <h2> How can I collaborate with TWOM Global for my project?</h2>
                                    <p>Collaborating with TWOM Global is simple! Contact us through our website or drop us an email. Our team will get in touch promptly to discuss your project, understand your requirements, and outline a tailored solution that aligns with your vision.</p>
                                </li>
                                <li>
                                    <input type="checkbox" checked>
                                    <i></i>
                                    <h2>How does TWOM Global ensure the confidentiality of client projects?
</h2>
                                    <p>Client confidentiality is a priority for us. We have stringent protocols in place to safeguard the privacy of our clients and their projects. Non-disclosure agreements can be arranged upon request for additional peace of mind.</p>
                                </li>
                                <li>
                                    <input type="checkbox" checked>
                                    <i></i>
                                    <h2>What types of clients does TWOM Global typically work with?
</h2>
                                    <p>TWOM Global collaborates with a diverse range of clients, including startups, established businesses, creative professionals, and organizations across various industries. Our adaptable approach allows us to cater to the unique needs of each client, regardless of size or sector.
</p>
                                </li>
                                <li>
                                    <input type="checkbox" checked>
                                    <i></i>
                                    <h2>How can I get a quote for my project from TWOM Global?
</h2>
                                    <p>To receive a quote for your project, simply reach out to us through our contact page or email. Provide details about your project scope, and our team will respond promptly with a customized quote and further information.</p>
                                </li>
                            </ul>
                        </div>
                    </section>
                </div>
                <div class="col-lg-5 mt-lg-0 mt-sm-5 mt-4">
                    <div class="banner-form-w3">
                        <!-- banner form -->
                        <form action="#" method="post">
                            <h3 class="title-style">Request a <span>Quote</span></h3>
                            <p class="mt-3 text-dark">Fill all information details to consult with us to get sevices
                                from us</p>
                            <div class="form-style-w3ls mt-4">
                                <input placeholder="Your Name" name="name" type="text" required="">
                                <input placeholder="Your Email" name="email" type="email" required="">
                                <input placeholder="Phone Number" name="phone" type="text" required="">
                                <button class="btn btn-style w-100"> Get a Quote</button>
                            </div>
                        </form>
                        <!-- //banner form -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- //faq section -->

    <!-- footer -->
   <?php include"footer.php"; ?>
    <!-- //footer -->

    <!-- Js scripts -->
    <!-- move top -->
    <button onclick="topFunction()" id="movetop" title="Go to top">
        <span class="fas fa-level-up-alt" aria-hidden="true"></span>
    </button>
    <script>
        // When the user scrolls down 20px from the top of the document, show the button
        window.onscroll = function () {
            scrollFunction()
        };

        function scrollFunction() {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                document.getElementById("movetop").style.display = "block";
            } else {
                document.getElementById("movetop").style.display = "none";
            }
        }

        // When the user clicks on the button, scroll to the top of the document
        function topFunction() {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        }
    </script>
    <!-- //move top -->

    <!-- common jquery plugin -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <!-- //common jquery plugin -->

    <!-- theme switch js (light and dark)-->
    <script src="assets/js/theme-change.js"></script>
    <!-- //theme switch js (light and dark)-->

    <!-- MENU-JS -->
    <script>
        $(window).on("scroll", function () {
            var scroll = $(window).scrollTop();

            if (scroll >= 80) {
                $("#site-header").addClass("nav-fixed");
            } else {
                $("#site-header").removeClass("nav-fixed");
            }
        });

        //Main navigation Active Class Add Remove
        $(".navbar-toggler").on("click", function () {
            $("header").toggleClass("active");
        });
        $(document).on("ready", function () {
            if ($(window).width() > 991) {
                $("header").removeClass("active");
            }
            $(window).on("resize", function () {
                if ($(window).width() > 991) {
                    $("header").removeClass("active");
                }
            });
        });
    </script>
    <!-- //MENU-JS -->

    <!-- disable body scroll which navbar is in active -->
    <script>
        $(function () {
            $('.navbar-toggler').click(function () {
                $('body').toggleClass('noscroll');
            })
        });
    </script>
    <!-- //disable body scroll which navbar is in active -->

    <!-- bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- //bootstrap -->
    <!-- //Js scripts -->
</body>

</html>