<!--
Author: W3layouts
Author URL: http://w3layouts.com
-->
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Storytelling, branding and digital experiences.

</title>
    <!-- google-fonts -->
    <link
        href="//fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <!-- //google-fonts -->
    <!-- Font-Awesome-Icons-CSS -->
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
    <!-- Template CSS Style link -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
</head>

<body>
<?php include"header.php";?>
    <!-- banner section -->
    <section id="home" class="w3l-banner py-5">
        <div class="banner-image">

        </div>
        <div class="banner-content">
            <div class="container pt-5 pb-md-4">
                <div class="row align-items-center py-4">
                    <div class="col-md-6 pr-lg-5">
                        <h3 class="mb-lg-4 mb-3 title">Storytelling, branding and <span>digital experiences</span></h3>
                        <p class="mr-5">At TWOM Global, we specialize in the art of storytelling, the essence of branding, and the innovation of digital experiences.</p>
                        <div class="mt-md-5 mt-4 mb-lg-0 mb-4">
                            <a class="btn btn-style" href="services">Our Services</a>
                        </div>
                    </div>
                    <div class="col-md-6 mt-md-0 mt-5 mb-lg-0 mb-5 right-banner-2 position-relative">
                        <div class="sub-banner-image">
                            <img src="assets/images/banner-img.jpg"
                                class="img-fluid radius-image-full position-relative" alt=" ">
                        </div>
                        <div class="banner-style-1 d-flex align-items-center">
                            <i class="fas fa-chart-line green-clr-bg"></i>
                            <h4>Branding</h4>
                        </div>
                        <div class="banner-style-1 banner-style-2 d-flex align-items-center">
                            <i class="fas fa-shield-alt primary-clr-bg"></i>
                            <h4>Digital Experiences</h4>
                        </div>
                        <div class="banner-style-1 banner-style-3 d-flex align-items-center">
                            <i class="fas fa-chart-area blue-clr-bg"></i>
                            <h4>Storytelling</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //banner section -->

    <!-- 3grids section -->
    <section class="about-section py-5">
        <div class="container py-lg-5 py-4">
            <div class="title-heading-w3 mx-auto text-center mb-sm-5 mb-4 pb-xl-4" style="max-width:600px">
                <h3 class="title-style mb-2">Why choose us?</h3>
                <p>We are your partners in bringing visions to life, transforming ideas into impactful realities. Here's why choosing TWOM Global is your gateway to unparalleled creativity and excellence.</p>
            </div>
            <div class="row justify-content-center text-center">
                <div class="col-lg-4 col-md-6">
                    <div class="about-single p-3">
                        <div class="about-icon mb-4">
                            <i class="fas fa-business-time primary-clr-bg"></i>
                        </div>
                        <div class="about-content">
                            <h5 class="mb-2"><a href="about.html">Global experience</a></h5>
                            <p>We have worked with multinational companies, as well as smaller businesses from all continents.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-md-0 mt-3">
                    <div class="about-single p-3">
                        <div class="about-icon mb-4">
                            <i class="fas fa-chart-pie green-clr-bg"></i>
                        </div>
                        <div class="about-content">
                            <h5 class="mb-2"><a href="about.html">Quality for value</a></h5>
                            <p>Our motto is to provide only the highest quality to our clients, no matter the circumstances.
</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-lg-0 mt-2">
                    <div class="about-single p-3">
                        <div class="about-icon mb-4">
                            <i class="fas fa-shipping-fast blue-clr-bg"></i>
                        </div>
                        <div class="about-content">
                            <h5 class="mb-2"><a href="about.html">High standards

</a></h5>
                            <p>We take data seriously, meaning that we only deliver work that we can be proud of.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //3grids section -->

    <!-- home block 3 -->
    <section class="w3l-servicesblock py-5">
        <div class="container pb-lg-5">
            <div class="row pb-xl-5 align-items-center">
                <div class="col-lg-6 position-relative home-block-3-left pb-lg-0 pb-5">
                    <div class="position-relative">
                        <img src="assets/images/home1.jpg" alt="" class="img-fluid radius-image">
                    </div>
                    <div class="imginfo__box">
                        <h6 class="imginfo__title">Crafting Visual Stories with Passion</h6>
                        <p> Get Noticed, Make an Impact,<br>  and Grow with Authentic Visuals </p>
                        <a href="tel:http://1(800)7654321"><span class="fa fa-phone mr-2"></span> +91-976-037-3493</a>
                    </div>

                </div>
                <div class="col-xl-5 col-lg-6 offset-xl-1 mt-lg-0 mt-5 pt-lg-0 pt-5">
                    <h3 class="title-style"> TWOM Global Proudly Supports Small Startups on Their Journey to Success
</h3>
                    <p class="mt-lg-4 mt-3 mb-sm-5 mb-4">We empower small and rural startups with personalized strategies, creative solutions, and dedicated support. </p>
                    <div class="two-grids mt-md-0 mt-md-5 mt-4">
                        <div class="grids_info">
                            <i class="fas fa-user-clock primary-clr-bg"></i>
                            <div class="detail">
                                <h4>Elevating Small Startups through Digital Impact</h4>
                                <p>From inception to impact, we guide you in establishing a strong online presence.</p>
                            </div>
                        </div>
                        <div class="grids_info mt-5">
                            <i class="fas fa-laptop-house green-clr-bg"></i>
                            <div class="detail">
                                <h4>Unveil Your Startup's Tale with TWOM Global</h4>
                                <p>Our Filmmaking Expertise Transforms Your Vision into a Compelling Story.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //home block 3 -->

   <?php include"our-services.php"; ?>
    <!-- //home page service block -->

    <!-- video section -->
    <section class="w3l-ab-section py-5">
        <div class="container py-md-5 py-4">
            <div class="row py-lg-4">
                <div class="col-lg-6 section-width align-self">
                    <h3 class="title-style pr-xl-5">We help businesses launch, grow and succeed</h3>
                    <p class="mt-lg-4 mt-3 pb-3">Whether you're a startup looking to make a mark, a growing business seeking to expand, or an established brand aiming to stay at the top, TWOM Global is your partner in the journey. Let's collaboratively write a success story that goes beyond visuals – a narrative that defines your brand and resonates with your audience, ensuring enduring success in the business world.</p>
                    <a href="services" class="btn btn-style mt-4">Our Services</a>
                </div>
                <div class="col-lg-6 history-info mt-5 pt-lg-0 pt-5">
                    <div class="position-relative img-border">
                        <img src="assets/images/video.jpg" class="img-fluid video-popup-image" alt="video-popup">

                        <a href="#small-dialog" class="popup-with-zoom-anim play-view text-center position-absolute">
                            <span class="video-play-icon">
                                <span class="fa fa-play"></span>
                            </span>
                        </a>
                        <!-- dialog itself, mfp-hide class is required to make dialog hidden -->
                        <div id="small-dialog" class="zoom-anim-dialog mfp-hide">
                            <iframe src="https://www.youtube.com/@TWOMGlobal/videos" allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //video section -->

    <?php
include"footer.php";
    ?>

    <!-- Js scripts -->
    <!-- move top -->
    <button onclick="topFunction()" id="movetop" title="Go to top">
        <span class="fas fa-level-up-alt" aria-hidden="true"></span>
    </button>
    <script>
        // When the user scrolls down 20px from the top of the document, show the button
        window.onscroll = function () {
            scrollFunction()
        };

        function scrollFunction() {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                document.getElementById("movetop").style.display = "block";
            } else {
                document.getElementById("movetop").style.display = "none";
            }
        }

        // When the user clicks on the button, scroll to the top of the document
        function topFunction() {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        }
    </script>
    <!-- //move top -->

    <!-- common jquery plugin -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <!-- //common jquery plugin -->

    <!-- banner image moving effect -->
    <script>
        var lFollowX = 0,
            lFollowY = 0,
            x = 0,
            y = 0,
            friction = 1 / 30;

        function animate() {
            x += (lFollowX - x) * friction;
            y += (lFollowY - y) * friction;

            translate = 'translate(' + x + 'px, ' + y + 'px) scale(1.1)';

            $('.banner-image').css({
                '-webit-transform': translate,
                '-moz-transform': translate,
                'transform': translate
            });

            window.requestAnimationFrame(animate);
        }

        $(window).on('mousemove click', function (e) {

            var lMouseX = Math.max(-100, Math.min(100, $(window).width() / 2 - e.clientX));
            var lMouseY = Math.max(-100, Math.min(100, $(window).height() / 2 - e.clientY));
            lFollowX = (20 * lMouseX) / 100; // 100 : 12 = lMouxeX : lFollow
            lFollowY = (10 * lMouseY) / 100;

        });

        animate();
    </script>
    <!-- //banner image moving effect -->

    <!-- magnific popup -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script>
        $(document).ready(function () {
            $('.popup-with-zoom-anim').magnificPopup({
                type: 'inline',

                fixedContentPos: false,
                fixedBgPos: true,

                overflowY: 'auto',

                closeBtnInside: true,
                preloader: false,

                midClick: true,
                removalDelay: 300,
                mainClass: 'my-mfp-zoom-in'
            });

            $('.popup-with-move-anim').magnificPopup({
                type: 'inline',

                fixedContentPos: false,
                fixedBgPos: true,

                overflowY: 'auto',

                closeBtnInside: true,
                preloader: false,

                midClick: true,
                removalDelay: 300,
                mainClass: 'my-mfp-slide-bottom'
            });
        });
    </script>
    <!-- //magnific popup -->

    <!-- theme switch js (light and dark)-->
    <script src="assets/js/theme-change.js"></script>
    <!-- //theme switch js (light and dark)-->

    <!-- MENU-JS -->
    <script>
        $(window).on("scroll", function () {
            var scroll = $(window).scrollTop();

            if (scroll >= 80) {
                $("#site-header").addClass("nav-fixed");
            } else {
                $("#site-header").removeClass("nav-fixed");
            }
        });

        //Main navigation Active Class Add Remove
        $(".navbar-toggler").on("click", function () {
            $("header").toggleClass("active");
        });
        $(document).on("ready", function () {
            if ($(window).width() > 991) {
                $("header").removeClass("active");
            }
            $(window).on("resize", function () {
                if ($(window).width() > 991) {
                    $("header").removeClass("active");
                }
            });
        });
    </script>
    <!-- //MENU-JS -->

    <!-- disable body scroll which navbar is in active -->
    <script>
        $(function () {
            $('.navbar-toggler').click(function () {
                $('body').toggleClass('noscroll');
            })
        });
    </script>
    <!-- //disable body scroll which navbar is in active -->

    <!-- bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- //bootstrap -->
    <!-- //Js scripts -->
</body>

</html>