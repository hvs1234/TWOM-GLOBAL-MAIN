<!--
Author: W3layouts
Author URL: http://w3layouts.com
-->
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Storytelling, branding and digital experiences.

</title>
    <!-- google-fonts -->
    <link
        href="//fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <!-- //google-fonts -->
    <!-- Font-Awesome-Icons-CSS -->
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
    <!-- Template CSS Style link -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
</head>

<body>
   <?php include"header.php";?>
    <!--//header-->

    <!-- inner banner -->
    <section class="inner-banner py-5">
        <div class="w3l-breadcrumb py-lg-5">
            <div class="container pt-4 pb-sm-4">
                <h4 class="inner-text-title font-weight-bold pt-5">About Us</h4>
                <ul class="breadcrumbs-custom-path">
                    <li><a href="index.html">Home</a></li>
                    <li class="active"><i class="fas fa-angle-right mx-2"></i>About</li>
                </ul>
            </div>
        </div>
    </section>
    <!-- //inner banner -->

    <!-- about block -->
    <section class="w3l-servicesblock py-5">
        <div class="container py-lg-5 py-4">
            <div class="row pt-xl-5 pt-lg-0 pt-5 pb-xl-4 align-items-center">
                <div class="col-lg-6 position-relative home-block-3-left">
                    <div class="position-relative">
                        <img src="assets/images/home2.jpg" alt="" class="img-fluid radius-image">
                    </div>
                </div>
                <div class="col-xl-5 col-lg-6 offset-xl-1 mt-lg-0 mt-5">
                    <h3 class="title-style">Welcome to Future-Oriented Hybrid Agency</h3>
                    <p class="mt-lg-4 mt-3 mb-sm-5 mb-4">Storytelling, branding and digital experiences.</p>
                    <div class="two-grids mt-md-0 mt-md-5 mt-4">
                        <div class="grids_info">
                            <i class="fas fa-user-clock primary-clr-bg"></i>
                            <div class="detail">
                                <h4>Our Mission</h4>
                                <p>TWOM Global: Empowering businesses through transformative storytelling, creating connections that captivate and drive success.</p>
                            </div>
                        </div>
                        <div class="grids_info mt-sm-5 mt-4">
                            <i class="fas fa-laptop-house green-clr-bg"></i>
                            <div class="detail">
                                <h4>Our Vision</h4>
                                <p>To redefine visual communication globally, becoming the premier creative partner recognized for excellence, innovation, and collaborative storytelling that inspires positive change.</p>
                            </div>
                        </div>
                        <div class="grids_info mt-sm-5 mt-4">
                            <i class="fas fa-laptop-house blue-clr-bg"></i>
                            <div class="detail">
                                <h4>Our Values</h4>
                                <p>TWOM Global values creative excellence, client success through collaboration, integrity and transparency, continuous growth, and a positive impact on society and the environment.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //about block -->

    <!-- stats -->
    <section class="w3_stats py-5" id="stats">
        <div class="container py-md-5 py-4">
            <div class="w3-stats text-center py-md-4">
                <div class="row mt-4">
                    <div class="col-md-3 col-6">
                        <div class="counter">
                            <i class="fas fa-users"></i>
                            <div class="timer count-title count-number mt-3" data-to="12" data-speed="1500"></div>
                            <p class="count-text">Team</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="counter">
                            <i class="far fa-smile"></i>
                            <div class="timer count-title count-number mt-3" data-to="126" data-speed="150"></div>
                            <p class="count-text">Happy Customers</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 mt-md-0 mt-5">
                        <div class="counter">
                            <i class="fas fa-box-open"></i>
                            <div class="timer count-title count-number mt-3" data-to="102" data-speed="1500"></div>
                            <p class="count-text">Projects</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 mt-md-0 mt-5">
                        <div class="counter">
                            <i class="fas fa-trophy"></i>
                            <div class="timer count-title count-number mt-3" data-to="86" data-speed="1500"></div>
                            <p class="count-text">Completed</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //stats -->

   
    <!-- testimonials section -->
    <section class="w3l-testimonials pb-5" id="testimonials">
        <div class="container py-md-5 py-4">
            <div class="title-heading-w3 mx-auto text-center mb-5 pb-xl-4" style="max-width:600px">
                <h3 class="title-style mb-2">What Our Clients Say!</h3>
                <p>
Discover the impact of TWOM Global through the words of our clients.
</p>
            </div>
            <div class="owl-testimonial owl-carousel owl-theme mx-auto" style="max-width:1000px">
                <div class="item">
                    <div class="slider-info">
                        <div class="img-circle">
                            <img src="assets/images/Gorki-Chandola.png" class="img-fluid rounded" alt="client image">
                        </div>
                        <div class="message-info">
                            <span class="fa fa-quote-left mr-2"></span>
                            <div class="message">I highly recommend TWOM Global to anyone seeking a dedicated, creative, and forward-thinking partner. Their ability to blend storytelling, branding, and digital innovation sets them apart, making them an indispensable asset for any project. Working with TWOM Global was not just a service; it was an enriching collaboration that elevated the entire creative process.</div>
                            <div class="name">- Maj.Gorki Chandola</div>
                            <div class="desp">Pathaal ,India</div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="slider-info">
                        <div class="img-circle">
                            <img src="assets/images/testi2.jpg" class="img-fluid rounded" alt="client image">
                        </div>
                        <div class="message-info">
                            <span class="fa fa-quote-left mr-2"></span>
                            <div class="message">I had the pleasure of working with TWOM Global on a critical project, and their creativity surpassed my expectations. Their team not only understood our vision but elevated it to new heights. The result was a visual masterpiece that resonated deeply with our audience. TWOM Global is not just a service provider; they are true partners in storytelling and business success</div>
                            <div class="name">- Sami Wade</div>
                            <div class="desp">Comapany ,City</div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="slider-info">
                        <div class="img-circle">
                            <img src="assets/images/testi3.jpg" class="img-fluid rounded" alt="client image">
                        </div>
                        <div class="message-info">
                            <span class="fa fa-quote-left mr-2"></span>
                            <div class="message">TWOM Global turned our brand vision into a visual reality that exceeded our wildest expectations. Their commitment to excellence, attention to detail, and strategic approach were truly commendable. The visuals crafted by TWOM Global became the cornerstone of our marketing efforts, driving engagement and propelling our brand to new heights. Working with them was not just a collaboration; it was a transformative experience</div>
                            <div class="name">- Smith roy</div>
                            <div class="desp">Comapany ,City</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //testimonials section -->

    <!-- footer -->
    <?php include"footer.php";?>
    <!-- //footer -->

    <!-- Js scripts -->
    <!-- move top -->
    <button onclick="topFunction()" id="movetop" title="Go to top">
        <span class="fas fa-level-up-alt" aria-hidden="true"></span>
    </button>
    <script>
        // When the user scrolls down 20px from the top of the document, show the button
        window.onscroll = function () {
            scrollFunction()
        };

        function scrollFunction() {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                document.getElementById("movetop").style.display = "block";
            } else {
                document.getElementById("movetop").style.display = "none";
            }
        }

        // When the user clicks on the button, scroll to the top of the document
        function topFunction() {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        }
    </script>
    <!-- //move top -->

    <!-- common jquery plugin -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <!-- //common jquery plugin -->

    <!-- theme switch js (light and dark)-->
    <script src="assets/js/theme-change.js"></script>
    <!-- //theme switch js (light and dark)-->

    <!-- counter for stats -->
    <script src="assets/js/counter.js"></script>
    <!-- //counter for stats -->

    <script src="assets/js/owl.carousel.js"></script>
    <!-- script for testimonials -->
    <script>
        $(document).ready(function () {
            $('.owl-testimonial').owlCarousel({
                loop: true,
                margin: 0,
                nav: true,
                responsiveClass: true,
                autoplay: true,
                autoplayTimeout: 5000,
                autoplaySpeed: 1000,
                autoplayHoverPause: false,
                responsive: {
                    0: {
                        items: 1,
                        nav: false
                    },
                    480: {
                        items: 1,
                        nav: false
                    },
                    667: {
                        items: 1,
                        nav: true
                    },
                    1000: {
                        items: 1,
                        nav: true
                    }
                }
            })
        })
    </script>
    <!-- //script for testimonials -->

    <!-- MENU-JS -->
    <script>
        $(window).on("scroll", function () {
            var scroll = $(window).scrollTop();

            if (scroll >= 80) {
                $("#site-header").addClass("nav-fixed");
            } else {
                $("#site-header").removeClass("nav-fixed");
            }
        });

        //Main navigation Active Class Add Remove
        $(".navbar-toggler").on("click", function () {
            $("header").toggleClass("active");
        });
        $(document).on("ready", function () {
            if ($(window).width() > 991) {
                $("header").removeClass("active");
            }
            $(window).on("resize", function () {
                if ($(window).width() > 991) {
                    $("header").removeClass("active");
                }
            });
        });
    </script>
    <!-- //MENU-JS -->

    <!-- disable body scroll which navbar is in active -->
    <script>
        $(function () {
            $('.navbar-toggler').click(function () {
                $('body').toggleClass('noscroll');
            })
        });
    </script>
    <!-- //disable body scroll which navbar is in active -->

    <!-- bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- //bootstrap -->
    <!-- //Js scripts -->
</body>

</html>