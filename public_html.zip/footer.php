<!-- footer -->
    <footer class="w3l-footer-29-main">
        <div class="footer-29 py-5">
            <div class="container py-lg-4">
                <div class="row footer-top-29">
                    <div class="col-lg-9">
                        <div class="row">
                            <div class="col-md-3 col-6 footer-list-29">
                                <ul>
                                    <h6 class="footer-title-29">Company</h6>
                                    <li><a href="services">About Our Services</a></li>
                                    <li><a href="#projects">Our Projects</a></li>
                                    <li><a href="#blog">View Our Blog</a></li>
                                    <li><a href="about">Check Our Careers</a></li>
                                </ul>
                            </div>
                            <div class="col-md-3 col-6 footer-list-29">
                                <ul>
                                    <h6 class="footer-title-29">Quick Links</h6>
                                    <li><a href="#management">Management</a></li>
                                    <li><a href="services">Department Services</a></li>
                                    <li><a href="#appointment">Make Appointment</a></li>
                                    <li><a href="about">Our Business Growth</a></li>
                                </ul>
                            </div>
                            <div class="col-md-3 col-6 footer-list-29 mt-md-0 mt-4">
                                <ul>
                                    <h6 class="footer-title-29">Support</h6>
                                    <li><a href="#live">Live Chart</a></li>
                                    <li><a href="#faq">Faq's</a></li>
                                    <li><a href="#support"> Support</a></li>
                                    <li><a href="#terms">Terms of Service</a></li>
                                </ul>
                            </div>
                            <div class="col-md-3 col-6 footer-list-29 mt-md-0 mt-4">
                                <h6 class="footer-title-29">More Info</h6>
                                <ul>
                                    <li><a href="#privacy">Privacy Policy</a></li>
                                    <li><a href="#terms"> Terms of Service</a></li>
                                    <li><a href="contact">Contact us</a></li>
                                    <li><a href="#support"> Support</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 footer-contact-list mt-lg-0 mt-md-5 mt-4">
                        <h6 class="footer-title-29">Social Media</h6>
                        <div class="main-social-footer-29">
                            <a href="https://www.facebook.com/profile.php?id=100094131202196" class="facebook"><i class="fab fa-facebook-f"></i></a>
                            <a href="#twitter" class="twitter"><i class="fab fa-twitter"></i></a>
                            <a href="#google"><i class="fab fa-google-plus-g"></i></a>
                            <a href="https://www.instagram.com/twomglobal/" class="instagram"><i class="fab fa-instagram"></i></a>
                        </div>
                        <!-- copyright -->
                        <p class="copy-footer-29 mt-4">© <?php echo date("Y"); ?> twomglobal.com.  </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- //footer -->